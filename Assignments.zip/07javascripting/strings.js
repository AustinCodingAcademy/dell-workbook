var somestring = 'this is a string';
console.log(somestring);