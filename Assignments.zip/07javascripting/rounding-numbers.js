var roundup = 1.5;
var rounded = Math.round(roundup);
console.log(rounded);
