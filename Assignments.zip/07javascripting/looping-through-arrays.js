var pets = ["cat", "dog", "rat"];
for (var i = 0; i < 3; i++) {
  pets[i] = pets[i] + "s";
}
console.log(pets);
