var pizzatoppings = ["tomato sauce", "cheese", "pepperoni"];
console.log(pizzatoppings);
